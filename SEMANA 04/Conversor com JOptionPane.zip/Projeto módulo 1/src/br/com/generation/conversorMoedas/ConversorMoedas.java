package br.com.generation.conversorMoedas;

import java.util.InputMismatchException;
import java.util.Scanner;

import javax.swing.*;
public class ConversorMoedas {

	public static void main(String[] args) {
			//--> Objeto das classes conversores...
			ConversorDolar cp = new ConversorDolar();
			ConversorIene cp1 = new ConversorIene();
			ConversorEuro cp2 = new ConversorEuro();
			ConversorRublo cp3 = new ConversorRublo();
			ConversorRenminbi cp4 = new ConversorRenminbi();
			ConversorReal cp5 = new ConversorReal ();
			ConversorLibra cp6 = new ConversorLibra();
			ConversorPesoArg cp7 = new ConversorPesoArg();
			ConversorDolarCan cp8 = new ConversorDolarCan();
			ConversorPesoCol cp9 = new ConversorPesoCol();
			
			// --> Página inicial, perguntando se o usuario deseja mesmo usar o conversor...
			for(int i = 0; i < 5; i++) {
			int us;
			// --> Tente
			try {
			//Integração JOption
				
			//--> Pagina inicial se deseja iniciar o conversor ou não
			us = Integer.parseInt(JOptionPane.showInputDialog(null, "Você deseja usar o conversor de moedas? " + "\n1) Seguir para o conversor" + 
			"\n2) Sair do programa", "Java Convert" , JOptionPane.QUESTION_MESSAGE));
			
			// --> Tratamento
			} catch (InputMismatchException f ) {
				us = Integer.parseInt(JOptionPane.showInputDialog(null, "Erro de digitação, tente novamente...", "Atenção" , JOptionPane.INFORMATION_MESSAGE));
				continue;
			}
			if(us == 2) {
				JOptionPane.showMessageDialog(null, "Saindo do conversor...", "Encerrando", JOptionPane.INFORMATION_MESSAGE);
				break;
			}else {
			
				switch (us) {
				case 1:
					JOptionPane.showMessageDialog(null, "            Bem-vindo, "
										+ "\nao conversor de moedas" , "Java Convert", JOptionPane.INFORMATION_MESSAGE);
					break;
				case 2:
					JOptionPane.showMessageDialog(null, "Saindo do conversor...", "Encerrando", JOptionPane.INFORMATION_MESSAGE);
				default:
					JOptionPane.showMessageDialog(null,"Invalido, tente novamente","Atenção",JOptionPane.WARNING_MESSAGE);
					continue;
				}
			}	
			
			// --> Looping até o usuario querer sair do programa...
			while(true) {
		
			int usuario;
			double valor;
			
			usuario = Integer.parseInt(JOptionPane.showInputDialog(null , "\n1- Dolar" + "\n2- Euro" + "\n3- Rublo" + 
					"\n4- Iene" + "\n5- Libra Esterlina" + "\n6- Reminbi" +
					"\n7- Real" + "\n8- Peso Argentino" + "\n9- Dolar Canadense" + 
					"\n10- Peso Colombiano" + "\n11- Sair", "Java Convert" , JOptionPane.QUESTION_MESSAGE));
			
			//--> Trata quando o usuario digitar letra, tanto na escolha da moeda, quanto no valor de conversão
			try {
			
			valor = Integer.parseInt(JOptionPane.showInputDialog(null,"Digite o valor para conversão: ", "Java Convert" , JOptionPane.QUESTION_MESSAGE));
			
	 	 	// --> Continua o código através do tratamento de letra, tanto quanto ao valor do usuairo. e o valor da conversão...
			} catch (InputMismatchException e) {
				usuario = Integer.parseInt(JOptionPane.showInputDialog("Erro de digitação, tente novamente..."));
				valor = Integer.parseInt(JOptionPane.showInputDialog(null, "Erro de digitação, tente novamente...", "Java Convert" , JOptionPane.QUESTION_MESSAGE));
				continue;
				}	
			//--> Para sair do programa
			if (usuario == 11 ){
				JOptionPane.showMessageDialog(null, "Saindo do programa...", "Encerrando", JOptionPane.INFORMATION_MESSAGE);
				System.exit(0);
	          
	         }
			// -->  Se não for sair do programa, ele executa o case...
			// -->  Pega o valor fixo, deixado nas classes para fazer a conta, enquanto imprimi o valor direto...
			else {
	             switch ( usuario ) {
	             case  1 : 
	            	 JOptionPane.showMessageDialog(null, "Dolar" + "\nDolar: US$" + valor + " → " + "Remimbi: ¥" + valor * cp.getRemimbi()
	            	 + "\nDolar: US$" + valor + " → " + "Euro: €" + valor * cp.getEuro()
	            	 + "\nDolar: US$" + valor + " → " + "Libra: £" + valor * cp.getLibra()
	            	 + "\nDolar: US$" + valor + " → " + "Rublo: ₽" + valor * cp.getRublo()
	            	 + "\nDolar: US$" + valor + " → " + "Peso Colombiano: $" + valor * cp.getPesCol()
	            	 + "\nDolar: US$" + valor + " → " + "Real: R$" + valor * cp.getReal()
	            	 + "\nDolar: US$" + valor + " → " + "Dolar Canadense $" + valor * cp.getDolCan()
	            	 + "\nDolar: US$" + valor + " → " + "Iene: ¥" + valor * cp.getIene()
	            	 + "\nDolar: US$" + valor + " → " + "Peso Argentino: $" + valor * cp.getPesArg(), "Java Convert", JOptionPane.PLAIN_MESSAGE);
	 				 System.exit(0);
	                 
	             case  2 :
	            	 JOptionPane.showMessageDialog(null, "Euro" + "\nEuro: €" + valor + " → " + "Remimbi: ¥" + valor * cp2.getRemimbi()
	            	 + "\nEuro: €" + valor + " → " + "Dolar: US$" + valor * cp2.getDolar()
	            	 + "\nEuro: €" + valor + " → " + "Libra: £" + valor * cp2.getLibra()
	            	 + "\nEuro: €" + valor + " → " + "Rublo: ₽" + valor * cp2.getRublo()
	            	 + "\nEuro: €" + valor + " → " + "Peso Colombiano: $" + valor * cp2.getPesCol()
	            	 + "\nEuro: €" + valor + " → " + "Real: R$" + valor * cp2.getReal()
	            	 + "\nEuro: €" + valor + " → " + "Dolar Canadense $" + valor * cp2.getDolCan()
	            	 + "\nEuro: €" + valor + " → " + "Iene: ¥" + valor * cp2.getIene()
	            	 + "\nEuro: €" + valor + " → " + "Peso Argentino: $" + valor * cp2.getPesoArg(), "Java Convert", JOptionPane.PLAIN_MESSAGE);
	            	 System.exit(0);
	                 
	             case  3 :
	            	 JOptionPane.showMessageDialog(null, "Rublo" + "\nRublo: ₽" + valor + " → " + "Remimbi: ¥" + valor * cp3.getRemimbi()
	            	 + "\nRublo: ₽" + valor + " → " + "Dolar: US$" + valor * cp3.getDolar()
	            	 + "\nRublo: ₽" + valor + " → " + "Libra: £" + valor * cp3.getLibra()
	            	 + "\nRublo: ₽" + valor + " → " + "Euro: €" + valor * cp3.getEuro()
	            	 + "\nRublo: ₽" + valor + " → " + "Peso Colombiano: $" + valor * cp3.getPesCol()
	            	 + "\nRublo: ₽" + valor + " → " + "Real: R$" + valor * cp3.getReal()
	            	 + "\nRublo: ₽" + valor + " → " + "Dolar Canadense $" + valor * cp3.getDolCan()
	            	 + "\nRublo: ₽" + valor + " → " + "Iene: ¥" + valor * cp3.getIene()
	            	 + "\nRublo: ₽" + valor + " → " + "Peso Argentino: $" + valor * cp3.getPesoArg(), "Java Convert", JOptionPane.PLAIN_MESSAGE);
	            	 System.exit(0);
	                 
	             case  4 :
	            	 JOptionPane.showMessageDialog(null, "Iene" + "\nIene: ¥" + valor + " → " + "Remimbi: ¥" + valor * cp1.getRemimbi()
	            	 + "\nIene: ¥" + valor + " → " + "Dolar: US$" + valor * cp1.getDolar()
	            	 + "\nIene: ¥" + valor + " → " + "Libra: £" + valor * cp1.getLibra()
	            	 + "\nIene: ¥" + valor + " → " + "Euro: €" + valor * cp1.getEuro()
	            	 + "\nIene: ¥" + valor + " → " + "Peso Colombiano: $" + valor * cp1.getPesCol()
	            	 + "\nIene: ¥" + valor + " → " + "Real: R$" + valor * cp1.getReal()
	            	 + "\nIene: ¥" + valor + " → " + "Dolar Canadense $" + valor * cp1.getDolCan()
	            	 + "\nIene: ¥" + valor + " → " + "Rublo: ₽" + valor * cp1.getRublo()
	            	 + "\nIene: ¥" + valor + " → " + "Peso Argentino: $" + valor * cp1.getPesoArg(), "Java Convert", JOptionPane.PLAIN_MESSAGE); 
	            	 System.exit(0);
	                 
	             case  5 :
	            	 JOptionPane.showMessageDialog(null, "Libra Esterlina" + "\nLibra: £" + valor + " → " + "Remimbi: ¥" + valor * cp6.getRemimbi()
	            	 + "\nLibra: £" + valor + " → " + "Dolar: US$" + valor * cp6.getDolar()
	            	 + "\nLibra: £" + valor + " → " + "Iene: ¥" + valor * cp6.getIene()
	            	 + "\nLibra: £" + valor + " → " + "Euro: €" + valor * cp6.getEuro()
	            	 + "\nLibra: £" + valor + " → " + "Peso Colombiano: $" + valor * cp6.getPesCol()
	            	 + "\nLibra: £" + valor + " → " + "Real: R$" + valor * cp6.getReal()
	            	 + "\nLibra: £" + valor + " → " + "Dolar Canadense $" + valor * cp6.getDolCan()
	            	 + "\nLibra: £" + valor + " → " + "Rublo: ₽" + valor * cp6.getRublo()
	            	 + "\nLibra: £" + valor + " → " + "Peso Argentino: $" + valor * cp6.getPesArg(), "Java Convert", JOptionPane.PLAIN_MESSAGE);     
	            	 System.exit(0);
	                 
	             case  6 :
	            	 JOptionPane.showMessageDialog(null, "Remimbi" + "\nRemimbi: ¥" + valor + " → " + "Libra: £" + valor * cp4.getLibra()
	            	 + "\nRemimbi: ¥" + valor + " → " + "Dolar: US$" + valor * cp4.getDolar()
	            	 + "\nRemimbi: ¥" + valor + " → " + "Iene: ¥" + valor * cp4.getIene()
	            	 + "\nRemimbi: ¥" + valor + " → " + "Euro: €" + valor * cp4.getEuro()
	            	 + "\nRemimbi: ¥" + valor + " → " + "Peso Colombiano: $" + valor * cp4.getPesoCol()
	            	 + "\nRemimbi: ¥" + valor + " → " + "Real: R$" + valor * cp4.getReal()
	            	 + "\nRemimbi: ¥" + valor + " → " + "Dolar Canadense $" + valor * cp4.getDolCan()
	            	 + "\nRemimbi: ¥" + valor + " → " + "Rublo: ₽" + valor * cp4.getRublo()
	            	 + "\nRemimbi: ¥" + valor + " → " + "Peso Argentino: $" + valor * cp4.getPesoArg(), "Java Convert", JOptionPane.PLAIN_MESSAGE);
	            	 System.exit(0);
	            	
	             case  7 :
	            	 JOptionPane.showMessageDialog(null, "Real" + "\nReal: R$" + valor + " → " + "Remimbi: ¥" + valor * cp5.getRemimbi()
	            	 + "\nReal: R$" + valor + " → " + "Dolar: US$" + valor * cp5.getDolar()
	            	 + "\nReal: R$" + valor + " → " + "Iene: ¥" + valor * cp5.getIene()
	            	 + "\nReal: R$" + valor + " → " + "Euro: €" + valor * cp5.getEuro()
	            	 + "\nReal: R$" + valor + " → " + "Peso Colombiano: $" + valor * cp5.getPesCol()
	            	 + "\nReal: R$" + valor + " → " + "Libra: £" + valor * cp5.getLibra()
	            	 + "\nReal: R$" + valor + " → " + "Dolar Canadense $" + valor * cp5.getDolCan()
	            	 + "\nReal: R$" + valor + " → " + "Rublo: ₽" + valor * cp5.getRublo()
	            	 + "\nReal: R$" + valor + " → " + "Peso Argentino: $" + valor * cp5.getPesArg(), "Java Convert", JOptionPane.PLAIN_MESSAGE);
	            	 System.exit(0);
	                 
	             case  8 :
	            	 JOptionPane.showMessageDialog(null, "Peso Argentino" + "\nPeso Argentino: $" + valor + " → " + "Remimbi: ¥" + valor * cp7.getRemimbi()
	            	 + "\nPeso Argentino: $" + valor + " → " + "Dolar: US$" + valor * cp7.getDolar()
	            	 + "\nPeso Argentino: $" + valor + " → " + "Iene: ¥" + valor * cp7.getIene()
	            	 + "\nPeso Argentino: $" + valor + " → " + "Euro: €" + valor * cp7.getEuro()
	            	 + "\nPeso Argentino: $" + valor + " → " + "Peso Colombiano: $" + valor * cp7.getPesCol()
	            	 + "\nPeso Argentino: $" + valor + " → " + "Real: R$" + valor * cp7.getReal()
	            	 + "\nPeso Argentino: $" + valor + " → " + "Dolar Canadense $" + valor * cp7.getDolCan()
	            	 + "\nPeso Argentino: $" + valor + " → " + "Rublo: ₽" + valor * cp7.getRublo()
	            	 + "\nPeso Argentino: $" + valor + " → " + "Libra: £" + valor * cp7.getLibra(), "Java Convert", JOptionPane.PLAIN_MESSAGE);
	            	 System.exit(0); 
	                 
	             case  9 :
	            	 JOptionPane.showMessageDialog(null, "Dolar Canadense" + "\nDolar Canadense: $" + valor + " → " + "Remimbi: ¥" + valor * cp8.getRemimbi()
	            	 + "\nDolar Canadense: $" + valor + " → " + "Dolar: US$" + valor * cp8.getDolar()
	            	 + "\nDolar Canadense: $" + valor + " → " + "Iene: ¥" + valor * cp8.getIene()
	            	 + "\nDolar Canadense: $" + valor + " → " + "Euro: €" + valor * cp8.getEuro()
	            	 + "\nDolar Canadense: $" + valor + " → " + "Peso Colombiano: $" + valor * cp8.getPesCol()
	            	 + "\nDolar Canadense: $" + valor + " → " + "Real: R$" + valor * cp8.getReal()
	            	 + "\nDolar Canadense: $" + valor + " → " + "Libra: £" + valor * cp8.getLibra()
	            	 + "\nDolar Canadense: $" + valor + " → " + "Rublo: ₽" + valor * cp8.getRublo()
	            	 + "\nDolar Canadense: $" + valor + " → " + "Peso Argentino: $" + valor * cp8.getPesArg(), "Java Convert", JOptionPane.PLAIN_MESSAGE);
	            	 System.exit(0);  
	                 
	             case  10 :
	            	 JOptionPane.showMessageDialog(null, "Peso Colombiano" + "\nPeso Colombiano: $" + valor + " → " + "Remimbi: ¥" + valor * cp9.getRemimbi()
	            	 + "\nPeso Colombiano: $" + valor + " → " + "Dolar: US$" + valor * cp9.getDolar()
	            	 + "\nPeso Colombiano: $" + valor + " → " + "Iene: ¥" + valor * cp9.getIene()
	            	 + "\nPeso Colombiano: $" + valor + " → " + "Euro: €" + valor * cp9.getEuro()
	            	 + "\nPeso Colombiano: $" + valor + " → " + "Libra: £" + valor * cp9.getLibra()
	            	 + "\nPeso Colombiano: $" + valor + " → " + "Real: R$" + valor * cp9.getReal()
	            	 + "\nPeso Colombiano: $" + valor + " → " + "Dolar Canadense $" + valor * cp9.getDolCan()
	            	 + "\nPeso Colombiano: $" + valor + " → " + "Rublo: ₽" + valor * cp9.getRublo()
	            	 + "\nPeso Colombiano: $" + valor + " → " + "Peso Argentino: $" + valor * cp9.getPesArg(), "Java Convert", JOptionPane.PLAIN_MESSAGE); 
	            	 System.exit(0); 
	                 
	             default :
	            	 JOptionPane.showMessageDialog(null,"Invalido, tente novamente","Atenção",JOptionPane.INFORMATION_MESSAGE);
	             	}	
				}
			}
			
		}
			
	}
	
}